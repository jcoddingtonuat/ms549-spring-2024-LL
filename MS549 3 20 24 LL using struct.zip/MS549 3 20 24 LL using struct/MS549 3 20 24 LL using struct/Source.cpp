#include <iostream>
using namespace std;

struct node
{
	int num;
	node* next;
};

node* head = NULL;
node* current = NULL;

void insert(int newNum) // inserting at the end
{
	struct node* newnode = new node;
	if (head == NULL)
	{
		head = newnode;
		current = newnode;

	}
	newnode->num = newNum;
	newnode->next = 0;
	current->next = newnode;
	current = newnode;

	cout << "newnode " << newnode << "  newnode data " << newnode->num;
}

void print()
{
	struct node* curr = head;
	while (curr != NULL)
	{
		cout << curr->num << endl;
		curr = curr->next;
	}
}

int main()
{

	for (int i = 1; i < 20; i++)
	{
		insert(i);
	}
	print();

	return 0;
}
