#include <iostream>
#include <list>

using namespace std;

void display(list<int> num)
{
	cout << "List:" << endl;
	for (int i : num)
	{
		cout << i << endl;
	}
}

int main()
{
	//create a list
	list<int> numbers = { 1,2,3,5,7 };
	display(numbers);

	numbers.push_front(42);
	display(numbers);

	numbers.push_back(12);
	display(numbers);

	numbers.pop_front();
	numbers.pop_back();
	display(numbers);

	return 0;
}